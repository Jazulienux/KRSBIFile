import cv2

cam = cv2.VideoCapture(0)

while True:
	_, frame = cam.read()

	if cv2.waitKey(27) == 27:
		break

	cv2.imshow("",frame)

cv2.destroyAllWindows()


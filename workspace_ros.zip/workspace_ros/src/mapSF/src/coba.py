#!/usr/bin/env python
import rospy
import cv2
import numpy as np
import sys
from geometry_msgs.msg import Vector3

def function(c,d):
	firstframe = 1


	image = cv2.imread('fieldKRSBI.png',cv2.IMREAD_COLOR)
	image = cv2.resize(image, (900,600))

	a = [c]
	b = [d]

	while (firstframe == 1):
		for i in range(len(a)):
			for y in range(len(b)):
				cv2.circle(image,(a[i],b[y]),15, (255,0,0), 30)
				print (i,y)
				cv2.imshow('test', image)
				if cv2.waitKey(33) & 0xFF == ord(' '):
					firstframe = 1
			i += 100
			

if __name__ == '__main__':
	c = input("A")
	d = input("B")
	function(c,d)

#!/usr/bin/env python
import rospy
import cv2
import numpy as np
import sys
from geometry_msgs.msg import Vector3

def listener():
	rospy.init_node("sub_odom",anonymous= True)
	rospy.Subscriber('/Mencoba',Vector3,callback)
	rospy.spin()

			
def callback(data):

	firstframe = 1

	image = cv2.imread('fieldKRSBI.png',cv2.IMREAD_COLOR)
	image = cv2.resize(image, (900,600))

	odom__baruX = data.x
	odom__baruY = data.y

	Mencoba(odom__baruX,odom__baruY, image)

def Mencoba(odom__baruX,odom__baruY, image):
	while True:
		asli = image
		odom_x = odom__baruX 	
		odom_y = odom__baruY

		rospy.loginfo(odom_x)
		rospy.loginfo(odom_y)

		a = odom_x
		b = odom_y

		cv2.circle(asli,(int(odom_x),int(odom_y)),15, (255,0,0), 30)
		
		print ("=======================================")
		print (a,b)
		print ("---------------------------------------")
		print (int(odom_x),int(odom_y))
		cv2.imshow('test', asli)
		if cv2.waitKey(33):
			break
				
if __name__ == '__main__':
	listener()
#!/usr/bin/env python
import rospy
import cv2
import numpy as np
import sys
from geometry_msgs.msg import Vector3

class MapSoccerField:

	def __init__(self):
		self.odometry_x = 0
		self.odometry_y = 0
		self.x = 0
		self.y = 0
		self.radius_x = self.x / 2
		self.radius_y = self.y / 2
		self.status = 0
		self.images = cv2.imread("fieldKRSBI.png",cv2.IMREAD_COLOR)
		self.images = cv2.resize(self.images,(900,600))
		self.patch = np.zeros((100,100,3) , dtype = np.uint8)
		self.listener()

	def callback(self,data):
		self.odometry_x = data.x 	
		self.odometry_y = data.y
		# print ("Data Rospy : ")
		# rospy.loginfo(self.odometry_x)
		# rospy.loginfo(self.odometry_y)
		# print ("-------------------------------------------")

		# baris = 0
		# kolom = 0

		# for row in range(250,350):
		# 	for col in range(400,500):
		# 		self.patch[baris,kolom] = self.images[row,col]
		# 		print self.patch[baris,kolom]
		# 		kolom += 1
		# 	baris+= 1
		# 	baris = 0


		# barisPatch = 0
		# kolomPatch = 0
		# for row in range(100,200):
		# 	for col in range(100,200):
		# 		self.images[row, col] = self.patch[barisPatch,kolomPatch]
		# 		barisPatch = barisPatch+1
		# 	barisPatch = barisPatch+1
		# 	kolomPatch=0


		self.x = (self.odometry_x * 900) / 9
		self.y = (self.odometry_y * 600) / 6

		cv2.circle(self.images,(int(self.x),int(self.y)), int(0.26/9 * 900), (255,0,0), 5)
			
		cv2.imshow("Mapping Posisioning Robot",self.images)
		cv2.imshow("Patch",self.patch)
		cv2.waitKey(2)
		# cv2.circle(self.images,(int(self.x),int(self.y)), int(0.26/9 * 900), (255,0,0), 5)


		# print (diameterRobot_x,diameterRobot_y)
		# print ("-------------------------------------------")

		#cv2.circle(self.images,(int(self.diameterRobot_x),int(self.diameterRobot_y)),15, (255,0,0), 1)
		# cv2.circle(self.images,(x,y), int(0.26/9 * 900), (255,0,0), 1)




	def listener(self):
		rospy.Subscriber('/odometry_fw',Vector3,self.callback)
		
if __name__ == '__main__':
	rospy.init_node("sub_odometry",anonymous= True)
	windows = MapSoccerField()
	# windows.__init__()
	rospy.spin()
							
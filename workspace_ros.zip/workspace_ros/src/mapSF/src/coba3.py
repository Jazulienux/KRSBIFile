#!/usr/bin/env python
import rospy
import cv2
import numpy as np

images = cv2.imread("fieldKRSBI.png",cv2.IMREAD_COLOR)
images = cv2.resize(images,(900,600))
patch = np.zeros((100,100, 3), dtype=np.uint8)
#while True:

i=0
j=0
for row in range(50,250):
	for col in range(100, 300):
		patch[i,j] = images[row,col]
		# print patch
		# print ('-----------------------------------------')
		j = j+1
	i = i+1
	j=0

i=0
j=0
for row in range(50,250):
	for col in range(100, 300):
		images[row, col] = patch[i,j]
		# print images
		j = j+1
	i = i+1
	j=0

cv2.imshow("Mapping Posisioning Robot",images)

cv2.imshow("patch", patch)
cv2.waitKey(0)
cv2.destroyAllWindows()


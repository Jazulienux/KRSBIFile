#!/usr/bin/env python
import rospy
import cv2
import copy
import numpy as np
import sys
from geometry_msgs.msg import Vector3

class Robsonema:
	def __init__(self):
		self.images = cv2.imread("fieldKRSBI.png",cv2.IMREAD_COLOR)
		self.images = cv2.resize(self.images,(900,600))

		# self.patch = np.zeros((100,100, 3), dtype="uint8")

		self.odometry_x = 0
		self.odometry_y = 0

		self.x = 0
		self.y = 0


		self.xPatch = 0
		self.yPatch = 0

		self.maks = 0
		self.min = 0

		self.terima_odom_patch_x = 0
		self.terima_odom_patch_y = 0

		self.listener()

	def callback(self, floatData):
		self.odometry_x = floatData.x
		self.odometry_y = floatData.y
		# self.terima_odom_patch_x = floatData.x
		# self.terima_odom_patch_y = floatData.y

		self.x = (self.odometry_x * 900) / 9
		self.y = (self.odometry_y * 600) / 6
		
		# self.xPatch = (self.terima_odom_patch_x * 900 ) / 9
		# self.yPatch = (self.terima_odom_patch_y * 600 ) / 6


		# if self.xPatch > self.yPatch:
		# 	self.maks = self.xPatch 
		# 	self.min = self.yPatch

		# elif self.yPatch > self.xPatch:
		# 	self.maks = self.yPatch
		# 	self.min = self.xPatch

		# print self.xPatch,self.yPatch
			

		# i=0
		# j=0
		# for row in range((int(self.min - 50)), (int(self.maks) - 50)):
		# 	for col in range((int(self.min + 50)), (int(self.maks) + 50)):
		# 		self.patch[i, j] = self.images[row,col]
		# 		# print self.patch
		# 		j = j+1
		# 	i = i+1
		# 	j=0

		# # print self.patch[99,99];
		# # print self.images[599,899];

		# i=0
		# j=0
		# for row in range((int(self.min - 50)), (int(self.maks) - 50)):
		# 	for col in range((int(self.maks + 50)), (int(self.maks) + 50)):
		# 		self.images[row, col] = self.patch[i,j]
		# 		# print self.images
		# 		j = j+1
		# 	i = i+1
		# 	j=0

		self.clone = copy.copy(self.images)


		cv2.circle(self.clone,(int(self.x),int(self.y)), int(0.26/9 * 900), (255,0,0), 5)
		cv2.line(self.clone,(int(self.x+10),int(self.y+10)), (int(self.x+30),int(self.y)), (255,0,0), 5)
		cv2.circle(self.clone,(int(self.y),int(self.x)), int(0.26/9 * 900), (0,0,255), 5)
		cv2.circle(self.clone,(int(self.x-1),int(self.x)), int(0.26/9 * 900), (0,0,0), 5)
		# cv2.circle(self.images,(int(self.x),int(self.y)), int(0.26/9 * 900), (255,0,0), 5)
		# cv2.imshow("Mapping Posisioning Robot",self.images)
		# cv2.imshow("Patch", self.patch)
		cv2.imshow("Patch", self.clone)

		cv2.waitKey(2)


	def listener(self):
		rospy.Subscriber('/odometry_fw',Vector3,self.callback)

if __name__ == '__main__':
	rospy.init_node("sub_odometry",anonymous= True)
	window = Robsonema()
	rospy.spin()
#!/usr/bin/env python
if __name__ == '__main__':
	for x in xrange(0,50):
		print x
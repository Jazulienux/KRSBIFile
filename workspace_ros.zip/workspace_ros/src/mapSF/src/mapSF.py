#!/usr/bin/env python
import rospy
import cv2
import numpy as np
import sys
from geometry_msgs.msg import Vector3

def callback(data):

	odom_x = data.x 	
	odom_y = data.y
	rospy.loginfo(odom_x)
	rospy.loginfo(odom_y)

	diameterRobot_x = (odom_x * 900) / 9
	diameterRobot_y = (odom_y * 600) / 6

	print (diameterRobot_x,diameterRobot_y)
	output(diameterRobot_x,diameterRobot_y)

def output(diameterRobot_x,diameterRobot_y):

	staFrame = True

	image = cv2.imread('fieldKRSBI.png',cv2.IMREAD_COLOR)
	image = cv2.resize(image, (900,600))

	while staFrame == True:
		a = image
		cv2.circle(a,(int(diameterRobot_x),int(diameterRobot_y)),15, (255,0,0), 30)

		cv2.imshow("Frame ",a)
		cv2.waitKey(0)
		# cv2.destroyAllWindows()


def listener():
	rospy.init_node("sub_odom",anonymous= True)
	rospy.Subscriber('/odometry_fw',Vector3,callback)
	rospy.spin()
	
if __name__ == '__main__':
	listener()
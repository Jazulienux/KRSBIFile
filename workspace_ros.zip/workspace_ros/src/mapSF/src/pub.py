#!/usr/bin/env python
import rospy
import cv2
import numpy as np
import sys
from geometry_msgs.msg import Vector3

def talker():

    pub = rospy.Publisher('odometry_fw', Vector3, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz

    msg = Vector3()
    x = 0
    y = 0
    while not rospy.is_shutdown():
        for i in range(0,10):
            for j in range(0,7):
                msg.x = i
                msg.y = j
                rospy.loginfo(msg)
                pub.publish(msg)
                rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
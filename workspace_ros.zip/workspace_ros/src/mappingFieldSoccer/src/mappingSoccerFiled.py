import cv2
import numpy as np

image = cv2.imread('fieldKRSBI.png',cv2.IMREAD_COLOR)
image = cv2.resize(image, (900,600))

x = input("Input X : ") 
y = input("Input Y : ")

cv2.circle(image,(x,y),30, (0,0,255), 3)

cv2.imshow("Frame ",image)
cv2.waitKey(0)
cv2.destroyAllWindows()
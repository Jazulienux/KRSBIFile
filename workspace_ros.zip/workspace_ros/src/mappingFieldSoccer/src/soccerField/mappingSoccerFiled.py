import rospy
import cv2
import numpy as np
import sys
from geometry_msgs import Vector3

def callback(data):

	global msg
	msg.float64.x = data.x 	
	msg.float64.y = data.y
	rospy.loginfo(odom_x)
	rospy.loginfo(odom_y)

	image = cv2.imread('fieldKRSBI.png',cv2.IMREAD_COLOR)
	image = cv2.resize(image, (900,600))

	diameterRobot_x = (odom_x * 900) / 9
	diameterRobot_y = (odom_y * 600) / 6

	print (diameterRobot_x,diameterRobot_y)

	cv2.circle(image,(diameterRobot_x,diameterRobot_y),15, (255,0,0), 30)

	cv2.imshow("Frame ",image)
	cv2.waitKey(0)
	cv2.destroyAllWindows()

def listener():
	global msg
	msg = Vector3()
	rospy.init_node("sub_odom",anonymous= True)
	rospy.Subsciber('/odometry_fw',float64,callback)
	
if __name__ == '__main__':
	listener()
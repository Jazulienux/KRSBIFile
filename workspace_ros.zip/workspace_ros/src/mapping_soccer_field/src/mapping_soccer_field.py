import cv2
import numpy as np

class detection_gawang:
	def __init__(self):
		self.cam = cv2.VideoCapture(0)
	
	def detection(self):
		while self.cam.isOpened():
			self.rate, self.frame = self.cam.read()

			cv2.imshow("Frame",self.frame)

			cv2.waitKey(0)

		# self.cam.release()
		# self.cam.destroyAllWindows()

if __name__ == '__main__':
	# cam = cv2.VideoCapture(0)

	# while cam.isOpened():
	# 	ret, frame = cam.read()

	# 	cv2.imshow("Frame",frame)
	# 	cv2.waitKey(0)
	detection_gawang().__init__

# cam.release()
# cam.destroyAllWindows()
#!/usr/bin/env python

import rospy
import socket 
from PyQt5 import QtCore, QtGui, QtWidgets, uic 
from PyQt5.QtWidgets import QLineEdit , QLabel , QMessageBox
from std_msgs.msg import String

class MyWindow(QtWidgets.QMainWindow):
	def __init__(self):
		super(MyWindow,self).__init__()
		uic.loadUi('Robsonema.ui',self)
		self.ConnectBtn.clicked.connect(self.OutputGUI)

	def OutputGUI(self):
		sCon = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		setIP = str(self.setIPText.toPlainText())
		sCon.connect((setIP,28097))

		try:	
			while True:
				terimaData = str(sCon.recv(1024))

				if terimaData == "W":
					pesan = terimaData + "--> Yaitu : Cyan / Magenta Team"
					terimaData = "ChT"
				elif terimaData == "s":
					pesan = terimaData + "--> Yaitu : Cyan / Magenta Start"
					terimaData = "Str"
				elif terimaData == "S":
					pesan = terimaData + "--> Yaitu : Cyan / Magenta Stop"
					terimaData = "Stp"
				elif terimaData == "L":
					pesan = terimaData + "--> Yaitu : Cyan / Magenta Park"
					terimaData = "Prk"
				elif terimaData == "N":
					pesan = terimaData + "--> Yaitu : Cyan / Magenta DropBall"
					terimaData = "Db"
				elif terimaData == "h":
					pesan = terimaData + "--> Yaitu : Cyan / Magenta HT"
					terimaData = "Ht"
					# terimaData = None
				elif terimaData == "e":
					pesan = terimaData + "--> Yaitu : Cyan / Magenta EndPart"
					terimaData = "Ep"
					# terimaData = None
				elif terimaData == "Z":
					terimaData = "Rs"
					pesan = terimaData + "--> Yaitu : Reset Game"
					terimaData = None


				elif terimaData == "K":
					pesan = terimaData + "--> Yaitu : Cyan KickOff"
					terimaData = "Kc"
				elif terimaData == "F":
					pesan = terimaData + "--> Yaitu : Cyan FreeCick"
					terimaData = "Fc"
				elif terimaData == "G":
					pesan = terimaData + "--> Yaitu : Cyan GoalKick"
					terimaData = "Gc"
				elif terimaData == "T":
					pesan = terimaData + "--> Yaitu : Cyan ThrowIn"
					terimaData = "Tc"
				elif terimaData == "C":
					pesan = terimaData + "--> Yaitu : Cyan CornerKick"
					terimaData = "Cc"
				elif terimaData == "P":
					pesan = terimaData + "--> Yaitu : Cyan PenaltyKick"
					terimaData = "Pc"
				elif terimaData == "O":
					pesan = terimaData + "--> Yaitu : Cyan Repair"
					terimaData = "Oc"
				elif terimaData == "A":
					pesan = terimaData + "--> Yaitu : Cyan Goal"
					terimaData = "Ac"
				elif(terimaData=="Y"):
					pesan = terimaData + "--> Yaitu : Cyan YellowCard"
					terimaData = "Yc"
				elif(terimaData=="R"):
					pesan = terimaData + "--> Yaitu : Cyan RedCard"
					terimaData = "Rc"


				elif(terimaData=="1"):
					pesan = terimaData + "--> Yaitu : 1 St"
				elif(terimaData=="2"):
					pesan = terimaData + "--> Yaitu : 2 Nd"
				elif(terimaData=="3"):
					pesan = terimaData + "--> Yaitu : Extra Time 1 St"
				elif(terimaData=="4"):
					pesan = terimaData + "--> Yaitu : Extra Time 2 Nd"

				elif(terimaData=="k"):
					pesan = terimaData + "--> Yaitu : Magenta KickOff"
					terimaData = "Km"
				elif(terimaData=="f"):
					pesan = terimaData + "--> Yaitu : Magenta FreeCick"
					terimaData = "Fm"
				elif(terimaData=="g"):
					pesan = terimaData + "--> Yaitu : Magenta GoalKick"
					terimaData = "Gm"
				elif(terimaData=="t"):
					pesan = terimaData + "--> Yaitu : Magenta ThrowIn"
					terimaData = "Tm"
				elif(terimaData=="c"):
					pesan = terimaData + "--> Yaitu : Magenta CornerKick"
					terimaData = "Cm"
				elif(terimaData=="p"):
					pesan = terimaData + "--> Yaitu : Magenta PenaltyKick"
					terimaData = "Pm"
				elif(terimaData=="o"):
					pesan = terimaData + "--> Yaitu : Magenta Repair"
					terimaData = "Om"
				elif(terimaData=="a"):
					pesan = terimaData + "--> Yaitu : Magenta Goal"
					terimaData = "Am"
				elif(terimaData=="y"):
					pesan = terimaData + "--> Yaitu : Magenta YellowCard"
					terimaData = "Ym"
				elif(terimaData=="r"):
					pesan = terimaData + "--> Yaitu : Magenta RedCard"
					terimaData = "Rm"
				else:
					terimaData = None

				print (pesan)
				print ("--------------------------------------------------------------------")

				pub = rospy.Publisher('refreeBox', String, queue_size=10)
				rospy.init_node('data_refreeBox', anonymous=True)
				rate = rospy.Rate(10)
				if not rospy.is_shutdown():
					dataRBox = terimaData
					print ("Data Dikirim : ")
					rospy.loginfo(dataRBox)
					print ("--------------------------------------------------------------------")
					pub.publish(dataRBox)
					rate.sleep()

				if terimaData is None:
					sCon.close()
					sys.exit(1)

		except KeyboardInterrupt:
			sys.exit(1)
		
if __name__ == '__main__':
	import sys
	app = QtWidgets.QApplication(sys.argv)
	window = MyWindow()
	window.show()
	sys.exit(app.exec_())
